<?php

return [
    'prefix' => 'user',
];
