<?php $__env->startSection('title'); ?>
    Detail Tajwid
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="content-wrapper-before teal"></div>
        <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
            <!-- Search for small screen-->
            <div class="container">
                <div class="row">
                    <div class="col s10 m6 l6">
                        <h5 class="breadcrumbs-title mt-0 mb-0"><b>DATA TAJWID</b></h5>
                        <ol class="breadcrumbs mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home.index')); ?>">Beranda</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('tajwid.index')); ?>">Data Tajwid</a></li>
                            <li class="breadcrumb-item active white-text"><b>Detail Tajwid</b></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="col s12">
            <div class="container">

            </div>
        </div>
        <div class="col s12">
            <div class="container mt-3">
                <!-- users list start -->

                <div class="card">
                    <div class="card-content">
                        <h5 class="caption"><b>"<?php echo e($data->nama_tajwid); ?>"</b><small class="deep-orange-text"><?php echo e(' ('.$data->kode.')'); ?></small></h5>
                    </div>
                </div>
                <div class="card">
                    <div class="row">
                        <div class="card-content">
                            <section class="penjelasan">
                                <?php echo $data->penjelasan; ?>

                            </section>
                        </div>
                    </div>
                </div>

                <!-- users list ends -->


            </div>
            <div class="content-overlay"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SP-Tajwid/resources/views/admin/tajwid/show.blade.php ENDPATH**/ ?>