<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Page Main-->

    <div class="row">

        


        
    </div>

    <!-- END: Page Main-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- BEGIN PAGE VENDOR JS-->




<!-- END PAGE VENDOR JS-->

<!-- BEGIN PAGE LEVEL JS-->


<!-- END PAGE LEVEL JS-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SP-Tajwid/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>