<?php $__env->startSection('title'); ?>
    Konsultasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/materialize-adm/vendors/select2/select2-materialize.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Page Main-->

    <div class="row">
        <div class="content-wrapper-before teal"></div>
        <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
            <!-- Search for small screen-->
            <div class="container" id="salam">
                <div class="row center-align">
                    <div class="col s12 m12 l12">
                        <h1 class="breadcrumbs-title mt-0 mb-0 font-kitab">
                            <?php echo e(html_entity_decode(json_decode('"\ufd3e \u0642\u064e\u0627\u0646\u06e1\u0633\u064f\u0644\u06e1\u062a\u064e\u0627\u0633\u0650\u064a\u06e1 \u062a\u064e\u0627\u062c\u06e1\u0648\u0650\u064a\u06e1\u062f \ufd3f"'), ENT_QUOTES, 'UTF-8')); ?>

                        </h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col s12">
        <div class="container mt-3">
            <div class="card">
                <div class="card-content">
                    <div class="judul">
                        <h1>Pilih salah satu surah dari 114 surah yang ada pada Al-Qur'an!</h1>
                    </div>
                    <form action="<?php echo e(route('get.ayah')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col s12">
                                <div class="input-field col m6 s12">
                                    <select class="select2 browser-default" name="surah">
                                        <option value="" disabled selected>--- Pilih Surah ---</option>
                                        <?php $__currentLoopData = $surahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($surah['number']); ?>">
                                                <?php echo e($surah['number'] . '. ' . $surah['englishName']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <button class="btn-small">Lanjut</button>
                    </form>
                </div>
            </div>

        </div>
    </div>

    <!-- END: Page Main-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/vendor/materialize-adm/vendors/select2/select2.full.min.js')); ?>"></script>

    
    <script>
        $(".select2").select2({
            dropdownAutoWidth: true,
            width: '100%',
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.konsultasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SP-Tajwid/resources/views/konsultasi/pilih-surah.blade.php ENDPATH**/ ?>