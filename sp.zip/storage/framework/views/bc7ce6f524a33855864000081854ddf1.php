<div class="footer-copyright">
  <div class="container">
    <span>&copy; 2022 <a href="" target="_blank">TIM IT Departemen Nasional 2 KMNU,</a> All rights reserved.</span>
  </div>
</div><?php /**PATH /var/www/html/SP-Tajwid/resources/views/partials/admin/footer.blade.php ENDPATH**/ ?>