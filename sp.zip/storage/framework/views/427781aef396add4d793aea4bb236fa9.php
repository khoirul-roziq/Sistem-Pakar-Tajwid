<div class="footer-copyright">
    <div class="container">
        <span>2023 <a href="" target="_blank">Khoirul Roziq </a>| Sistem Pakar Tajwid | Tugas Akhir</span>
    </div>
</div>
<?php /**PATH /var/www/html/SP-Tajwid/resources/views/partials/footer.blade.php ENDPATH**/ ?>