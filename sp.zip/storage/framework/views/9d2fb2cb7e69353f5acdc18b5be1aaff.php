<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- BEGIN: VENDOR CSS-->

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/materialize-src/css/vendors.min.css')); ?>">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('assets/vendor/materialize-src/css/materialize.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/materialize-src/css/style.min.css')); ?>">

    <!-- END: VENDOR CSS-->


    <!-- BEGIN: Custom CSS-->
        <?php echo $__env->yieldContent('styles'); ?>
    <!-- END: Custom CSS-->


    <title>Beranda &mdash; Sistem Pakar Tajwid</title>

</head>

<body>

    <header>
            <?php echo $__env->make('partials.home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <main>
            <?php echo $__env->make('partials.home.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>

    <footer class="page-footer teal center">
            <?php echo $__env->make('partials.home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials.home.sosmed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials.home.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>


    <!-- BEGIN VENDOR JS-->
    <script src="<?php echo e(asset('assets/vendor/materialize-src/js/vendors.min.js')); ?>"></script>
    <!-- BEGIN PAGE VENDOR JS-->

    <!-- BEGIN PAGE LEVEL JS-->
        <?php echo $__env->yieldContent('scripts'); ?>
    <!-- END PAGE LEVEL JS-->
</body>

</html>
<?php /**PATH /var/www/html/SP-Tajwid/resources/views/layouts/home-page.blade.php ENDPATH**/ ?>