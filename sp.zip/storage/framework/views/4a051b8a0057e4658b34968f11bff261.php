<?php $__env->startSection('title'); ?>
    Konsultasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Page Main-->

    <div class="row">
        <div class="content-wrapper-before teal"></div>
        <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
            <!-- Search for small screen-->
            <div class="container" id="salam">
                <div class="row center-align">
                    <div class="col s12 m12 l12">
                        <h1 class="breadcrumbs-title mt-0 mb-0 font-kitab">
                            <?php echo e(html_entity_decode(json_decode('"\ufd3e \u0642\u064e\u0627\u0646\u06e1\u0633\u064f\u0644\u06e1\u062a\u064e\u0627\u0633\u0650\u064a\u06e1 \u062a\u064e\u0627\u062c\u06e1\u0648\u0650\u064a\u06e1\u062f \ufd3f"'), ENT_QUOTES, 'UTF-8')); ?>

                        </h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col s12">
        <div class="container mt-3">
            <div class="card">
                <div class="card-content">
                    <div class="judul">
                        <h1><?php echo $pertanyaan->soal; ?></h1>
                    </div>
                    <div class="opsi row">
                        <div class="col s12">
                            <?php $__currentLoopData = $pertanyaan->jawaban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="<?php echo e(route('ghunnah', 2)); ?>" method="post" class="mt-1 mb-2 col">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" value="<?php echo e($jawaban->representasi); ?>" name="jawaban" hidden>
                                    <button type="submit" class="btn">
                                        <?php if($jawaban->kategori == 'hukum'): ?>
                                            <span><?php echo e($jawaban->representasi); ?></span>
                                        <?php elseif($jawaban->kategori == 'tanda'): ?>
                                            <span
                                                class="font-kitab"><?php echo e(html_entity_decode(json_decode('"' . $jawaban->representasi . '"'), ENT_QUOTES, 'UTF-8')); ?></span>
                                        <?php else: ?>
                                            <span>-</span>
                                        <?php endif; ?>
                                    </button>
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- END: Page Main-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SP-Tajwid/resources/views/guest/pertanyaan.blade.php ENDPATH**/ ?>