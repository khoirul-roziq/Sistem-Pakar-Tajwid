<?php $__env->startSection('styles'); ?>
  <?php echo $__env->yieldContent('styles'); ?>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-body'); ?>
    <body style="background-image: url(<?php echo e(asset('assets/images/background/islamic-new-year-concept-with-copy-space.jpg')); ?>);" class="vertical-layout vertical-menu-collapsible page-header-dark vertical-modern-menu preload-transitions 2-columns" data-open="click" data-menu="vertical-modern-menu" data-col="2-columns" onload = "autoClick();">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('app'); ?>

  <div id="main">
    <?php echo $__env->yieldContent('content'); ?>
  </div>

  <footer class="page-footer footer footer-static footer-dark gradient-45deg-indigo-purple gradient-shadow navbar-border navbar-shadow">
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </footer>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <?php echo $__env->yieldContent('scripts'); ?>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.skeleton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SP-Tajwid/resources/views/layouts/main.blade.php ENDPATH**/ ?>