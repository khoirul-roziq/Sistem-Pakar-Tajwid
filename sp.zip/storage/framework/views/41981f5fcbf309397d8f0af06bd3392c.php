<div class="navbar navbar-fixed">
  <nav class="navbar-main navbar-color nav-collapsible sideNav-lock navbar-dark teal lighten-1">
    <div class="nav-wrapper">
      
    
      <ul class="navbar-list right">
        
        
        <li>
          <a class="waves-effect waves-block waves-light profile-button" href="javascript:void(0);" data-target="profile-dropdown">
            
            <span style="font-weight: bold"><?php echo e(Auth::user()->name); ?></span>            
          </a>
        </li>
        <li class="hide-on-med-and-down"><a class="waves-effect waves-block waves-light toggle-fullscreen" href="javascript:void(0);"><i class="material-icons">settings_overscan</i></a></li>
      </ul>


      <!-- profile-dropdown-->
      <ul class="dropdown-content" id="profile-dropdown">
        <li><span class="grey-text text-darken-1 center">
          <?php if( Auth::user()->role == 'admin'): ?>
            <small>Role</small> <b>Administrator</b>
          <?php else: ?>
          <small>Role</small> <b>Tamu</b>
          <?php endif; ?>
        </span></li>
        <li class="divider"></li>
        <li><a class="grey-text text-darken-1" href=""><i class="material-icons">person_outline</i> Profil</a></li>
        <li><a class="grey-text text-darken-1" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="material-icons">keyboard_tab</i> Keluar</a></li>
        <form action="
        <?php echo e(route('logout')); ?>" id="logout-form" method="post">
          <?php echo csrf_field(); ?>
        </form>
      </ul>
    </div>
    
  </nav>
</div><?php /**PATH /var/www/html/SP-Tajwid/resources/views/partials/guest/header.blade.php ENDPATH**/ ?>