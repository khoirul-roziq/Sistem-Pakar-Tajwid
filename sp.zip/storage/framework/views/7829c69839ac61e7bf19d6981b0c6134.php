<?php $__env->startSection('title'); ?>
    Konsultasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Page Main-->

    <div class="row">
        <div class="content-wrapper-before teal"></div>
        <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
            <!-- Search for small screen-->
            <div class="container" id="salam">
                <div class="row center-align">
                    <div class="col s12 m12 l12">
                        <h1 class="breadcrumbs-title mt-0 mb-0 font-kitab">
                            <?php echo e(html_entity_decode(json_decode('"\ufd3e \u0642\u064e\u0627\u0646\u06e1\u0633\u064f\u0644\u06e1\u062a\u064e\u0627\u0633\u0650\u064a\u06e1 \u062a\u064e\u0627\u062c\u06e1\u0648\u0650\u064a\u06e1\u062f \ufd3f"'), ENT_QUOTES, 'UTF-8')); ?>

                        </h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if(session('message')): ?>
        <div class="col s12">
            <div class="container mt-3">
                <div class="card">
                    <div class="card-content">
                        <div class="row">
                            <div class="col s10 m12 l12">
                                <div class="card-alert card cyan">
                                    <div class="card-content white-text">
                                        <p>
                                            <i class="material-icons">check</i> <?php echo e(session('message')); ?>

                                        </p>
                                    </div>
                                    <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="col s12">
        <div class="container mt-3">
            <div class="card">
                <div class="card-content">
                    <div class="judul">
                        <h1><?php echo $pertanyaan->soal; ?></h1>
                    </div>
                    <div class="opsi row">
                        <div class="col s12">
                            <?php if($kode == 'K000'): ?>
                                <?php $__currentLoopData = $pertanyaan->kategoriJawaban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <form action="<?php echo e(route('konsultasi')); ?>" method="post" class="mt-1 mb-2 col">
                                        <?php echo csrf_field(); ?>
                                        <input type="text" value="<?php echo e($pertanyaan->id); ?>" name="reference" hidden>
                                        <input type="text" value="<?php echo e($kategori->kode); ?>" name="jawaban" hidden>
                                        <button type="submit"
                                            class="btn 
                                        <?php if(session()->has('kategori')): ?> <?php if(session('kategori') == $kategori->id): ?>
                                            pink darken-3 <?php endif; ?>`
                                        <?php endif; ?>
                                        ">
                                            <?php echo e($kategori->nama_kategori); ?>

                                        </button>
                                    </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php if($kode == 'H000'): ?>
                                    <?php $__currentLoopData = $pertanyaan->tajwidJawaban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tajwid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <form action="<?php echo e(route('konsultasi')); ?>" method="post" class="mt-1 mb-2 col">
                                            <?php echo csrf_field(); ?>
                                            <input type="text" value="<?php echo e($pertanyaan->id); ?>" name="reference" hidden>
                                            <input type="text" value="<?php echo e($tajwid->kode); ?>" name="jawaban" hidden>
                                            <button type="submit"
                                                class="btn
                                            <?php if(session()->has('tajwid')): ?> <?php if(session('tajwid') == $tajwid->id): ?>
                                                pink darken-3 <?php endif; ?>`
                                            <?php endif; ?>
                                            ">
                                                <?php echo e($tajwid->nama_tajwid); ?>

                                            </button>
                                        </form>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $pertanyaan->tandaTajwidJawaban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tandaTajwid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <form action="<?php echo e(route('konsultasi')); ?>" method="post" class="mt-1 mb-2 col">
                                            <?php echo csrf_field(); ?>
                                            <input type="text" value="<?php echo e($pertanyaan->id); ?>" name="reference" hidden>
                                            <input type="text" value="<?php echo e($pertanyaan->last_question); ?>"
                                                name="lastQuestion" hidden>
                                            <input type="text" value="<?php echo e($kode); ?>" name="kode" hidden>
                                            <input type="text" value="<?php echo e($tandaTajwid->kode); ?>" name="jawaban" hidden>
                                            <button type="submit"
                                                class="btn-large 
                                                <?php if(session()->has('pertanyaan')): ?> <?php if(in_array($pertanyaan->id, session('pertanyaan'))): ?>
                                                        <?php if($tandaTajwid->kode == session('jawaban')[array_search($pertanyaan->id, session('pertanyaan'))]): ?> pink darken-3 <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                ">

                                                <?php if($tandaTajwid->jenis == 'huruf'): ?>
                                                    <span class="font-kitab"
                                                        style="font-size:25px;"><?php echo e(html_entity_decode(json_decode('"' . $tandaTajwid->unicode . '"'), ENT_QUOTES, 'UTF-8')); ?></span>
                                                <?php elseif($tandaTajwid->jenis == 'tanda'): ?>
                                                    <?php if($tandaTajwid->unicode == '\n'): ?>
                                                        Waqof
                                                    <?php else: ?>
                                                        <span class="font-kitab"
                                                            style="font-size:25px;"><?php echo e(html_entity_decode(json_decode('"' . '—' . $tandaTajwid->unicode . '"'), ENT_QUOTES, 'UTF-8')); ?></span>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>

                                            </button>
                                        </form>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- END: Page Main-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.konsultasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SP-Tajwid/resources/views/konsultasi/pertanyaan.blade.php ENDPATH**/ ?>