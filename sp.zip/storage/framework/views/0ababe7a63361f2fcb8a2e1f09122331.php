<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/css/home.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SP-Tajwid/resources/views/home/index.blade.php ENDPATH**/ ?>