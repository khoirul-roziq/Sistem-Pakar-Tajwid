<div class="brand-sidebar">
  <h1 class="logo-wrapper"><a class="brand-logo darken-1" href="<?php echo e(url('/')); ?>"><img class="hide-on-med-and-down" src="<?php echo e(asset('assets/images/logo/logo-kmnu(210x140).jpg')); ?>" alt="Logo KMNU"/><img class="show-on-medium-and-down hide-on-med-and-up" src="<?php echo e(asset('assets/images/logo/logo-kmnu(210x140).jpg')); ?>" alt="materialize logo"/><span class="logo-text hide-on-med-and-down"> SP Tajwid</span></a><a class="navbar-toggler" href="#"><i class="material-icons">radio_button_checked</i></a></h1>
</div>
<ul class="sidenav leftside-navigation collapsible sidenav-fixed menu-shadow" id="slide-out" data-menu="menu-navigation" data-collapsible="menu-accordion">
  
  
  
  
</ul>


<div class="navigation-background"></div><a class="sidenav-trigger btn-sidenav-toggle btn-floating btn-medium waves-effect waves-light hide-on-large-only white" href="#" data-target="slide-out"><i class="material-icons">menu</i></a><?php /**PATH /var/www/html/SP-Tajwid/resources/views/partials/guest/sidebar.blade.php ENDPATH**/ ?>