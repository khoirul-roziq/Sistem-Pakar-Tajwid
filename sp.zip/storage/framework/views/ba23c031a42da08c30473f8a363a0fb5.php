<section id="pengertian">
    <h3 class="teal-text"><b>Apa itu Sistem Pakar Tajwid?</b></h3>
    <p style="font-size: 20px; color:rgb(78, 78, 78);">Sistem Pakar Tajwid adalah perangkat lunak atau aplikasi berbasis website yang mampu mensimulasikan pengetahuan
        dari ahli tajwid atau orang yang memiliki pengetahuan tentang ilmu tajwid. Sistem pakar ini menerapkan metode
        konsultasi, dengan cara memilih opsi jawaban untuk setiap pertanyaan hingga menghasilkan kesimpulan berupa
        penjelasan hukum tajwid.</p>
</section>




<?php /**PATH /var/www/html/SP-Tajwid/resources/views/partials/home/main.blade.php ENDPATH**/ ?>