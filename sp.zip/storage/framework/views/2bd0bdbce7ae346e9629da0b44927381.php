<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="https://alquran.cloud/public/css/font-kitab.css?v=1">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/css/dashboard.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Page Main-->
    <div class="row">
        <div class="content-wrapper-before teal"></div>
        <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
            <!-- Search for small screen-->
            <div class="container" id="salam">
                <div class="row center-align">
                    <div class="col s12 m12 l12">
                        <h1 class="breadcrumbs-title mt-0 mb-0 font-kitab" id="salam">ٱلسَّلَامُ عَلَيْكُمْ وَرَحْمَةُ ٱللَّٰهِ وَبَرَكَاتُهُ</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col s12">
            <div class="container mt-3">
                <div class="card">
                    <div class="card-content">
                        <h1>Selamat Datang, <?php echo e(Auth::user()->name); ?>!</h1>
                        <h2>Anda sekarang masuk sebagai <?php echo e(Auth::user()->role); ?>.</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col s12 menu">
            <div class="row">
                <div class="col s12 m6 l3">
                    <a href="<?php echo e(route('tajwid.index')); ?>">
                        <div class="card">
                            <div class="card-content">
                                <img src="<?php echo e(asset('assets/images/icons/data-tajwid.jpg')); ?>" alt="data-tajwid" width="80%">
                                <p>Data Tajwid</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col s12 m6 l3">
                    <a href="<?php echo e(route('role-base.index')); ?>">
                        <div class="card">
                            <div class="card-content">
                                <img src="<?php echo e(asset('assets/images/icons/role-base.jpg')); ?>" alt="role-base" width="80%">
                                <p>Role Base</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col s12 m6 l3">
                    <a href="<?php echo e(route('kategori.index')); ?>">
                        <div class="card">
                            <div class="card-content">
                                <img src="<?php echo e(asset('assets/images/icons/kategori.jpg')); ?>" alt="kategori" width="80%">
                                <p>Kategori</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col s12 m6 l3">
                    <a href="<?php echo e(route('tanda-tajwid.index')); ?>">
                        <div class="card">
                            <div class="card-content">
                                <img src="<?php echo e(asset('assets/images/icons/tanda-tajwid.jpg')); ?>" alt="tanda-tajwid" width="80%">
                                <p>Huruf/ Tanda</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col s12 m6 l3">
                    <a href="<?php echo e(route('pertanyaan.index')); ?>">
                        <div class="card">
                            <div class="card-content">
                                <img src="<?php echo e(asset('assets/images/icons/pertanyaan.jpg')); ?>" alt="pertanyaan" width="80%">
                                <p>Pertanyaan</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col s12 m6 l3">
                    <a href="<?php echo e(route('konsultasi.mulai')); ?>">
                        <div class="card">
                            <div class="card-content">
                                <img src="<?php echo e(asset('assets/images/icons/konsultasi.jpg')); ?>" alt="konsultasi" width="80%">
                                <p>Konsultasi</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col s12 m6 l3">
                    <a href="<?php echo e(route('data-user.index')); ?>">
                        <div class="card">
                            <div class="card-content">
                                <img src="<?php echo e(asset('assets/images/icons/data-user.jpg')); ?>" alt="data-user" width="80%">
                                <p>Data User</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- END: Page Main-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- BEGIN PAGE VENDOR JS-->




<!-- END PAGE VENDOR JS-->

<!-- BEGIN PAGE LEVEL JS-->


<!-- END PAGE LEVEL JS-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SP-Tajwid/resources/views/admin/dashboard/admin.blade.php ENDPATH**/ ?>