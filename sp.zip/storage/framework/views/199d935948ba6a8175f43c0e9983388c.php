<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- BEGIN: VENDOR CSS-->

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/materialize-src/css/vendors.min.css')); ?>">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/materialize-src/css/materialize.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/materialize-src/css/style.min.css')); ?>">

    <!-- END: VENDOR CSS-->

    
    <!-- BEGIN: Custom CSS-->
    <?php echo $__env->yieldContent('styles'); ?>
    <!-- END: Custom CSS-->


    <title><?php echo $__env->yieldContent('title'); ?> &mdash; Sistem Pakar Tajwid</title>

</head>

<body style="background-image: url(<?php echo e(asset('assets/images/background/auth-bg.jpg')); ?>);">

<main>
  <?php echo $__env->yieldContent('main'); ?>
</main>

    
    <!-- BEGIN VENDOR JS-->
    <script src="<?php echo e(asset('assets/vendor/materialize-src/js/vendors.min.js')); ?>"></script>
    <!-- BEGIN PAGE VENDOR JS-->

    <!-- BEGIN PAGE LEVEL JS-->
    <?php echo $__env->yieldContent('scripts'); ?> 
    <!-- END PAGE LEVEL JS-->
</body>
</html><?php /**PATH /var/www/html/SP-Tajwid/resources/views/layouts/auth.blade.php ENDPATH**/ ?>