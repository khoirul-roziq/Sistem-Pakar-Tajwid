<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="DOIS KMNU merupakan perangkat lunak berbasis website yang dikembangkan untuk mengelola data supaya meningkatkan efisiensi waktu pengelolaan dan meningkatkan integritas data">
    <meta name="keywords" content="kmnu, mahasiswa, nahdlatul ulama">
    <meta name="author" content="TIM IT Departemen Nasional 2 KMNU">
    <title><?php echo $__env->yieldContent('title'); ?> &mdash; DOIS KMNU Pusat</title>
    <link rel="apple-touch-icon" href="<?php echo e(asset('images/favicon/apple-touch-icon-152x152.png')); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/logo/logo-kmnu(210x140).jpg')); ?>">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- BEGIN: VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="https://pixinvent.com/materialize-material-design-admin-template/app-assets/vendors/vendors.min.css">
    <!-- END: VENDOR CSS-->

    <!-- BEGIN: Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="https://pixinvent.com/materialize-material-design-admin-template/app-assets/css/themes/vertical-modern-menu-template/materialize.min.css">
    <link rel="stylesheet" type="text/css" href="https://pixinvent.com/materialize-material-design-admin-template/app-assets/css/themes/vertical-modern-menu-template/style.min.css">
    <!-- END: Page Level CSS-->
    
    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="https://pixinvent.com/materialize-material-design-admin-template/app-assets/css/custom/custom.css">
    <!-- END: Custom CSS-->

    <?php echo $__env->yieldContent('styles'); ?>
  </head>

  <body class="vertical-layout vertical-menu-collapsible page-header-dark vertical-modern-menu preload-transitions 2-columns" data-open="click" data-menu="vertical-modern-menu" data-col="2-columns" onload = "autoClick();">
    <div id="app">
      <?php echo $__env->yieldContent('app'); ?>
    </div>

    <!-- BEGIN VENDOR JS-->
    <script src="https://pixinvent.com/materialize-material-design-admin-template/app-assets/js/vendors.min.js"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN THEME  JS-->
    <script src="https://pixinvent.com/materialize-material-design-admin-template/app-assets/js/plugins.min.js"></script>
    <script src="https://pixinvent.com/materialize-material-design-admin-template/app-assets/js/search.min.js"></script>
    <script src="https://pixinvent.com/materialize-material-design-admin-template/app-assets/js/custom/custom-script.min.js"></script>
    <script src="https://pixinvent.com/materialize-material-design-admin-template/app-assets/js/scripts/customizer.min.js"></script>
    <!-- END THEME  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <?php echo $__env->yieldContent('scripts'); ?> 
    <!-- END PAGE LEVEL JS-->
    
  </body>
</html><?php /**PATH /var/www/html/SP-Tajwid/resources/views/layouts/skeleton-admin.blade.php ENDPATH**/ ?>