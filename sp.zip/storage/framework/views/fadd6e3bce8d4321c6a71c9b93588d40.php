<div class="brand-sidebar">
  <h1 class="logo-wrapper"><a class="brand-logo darken-1" href="<?php echo e(url('/home')); ?>"><img class="hide-on-med-and-down" src="<?php echo e(asset('assets/images/logo/Al-Qur\'an_logo.jpg')); ?>" alt="materialize logo"/><span class="logo-text hide-on-med-and-down"> SP Tajwid</span></a><a class="navbar-toggler" href="#"><i class="material-icons">radio_button_checked</i></a></h1>
</div>
<ul class="sidenav leftside-navigation collapsible sidenav-fixed menu-shadow" id="slide-out" data-menu="menu-navigation" data-collapsible="menu-accordion">
  
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role',['admin'])): ?>
  
  <li class="bold"><a class="<?php echo e(Route::is('dashboard.*') ? 'actived' : ''); ?> waves-effect waves-cyan mt-5" href="<?php echo e(route('dashboard.index')); ?>"><i class="material-icons">dashboard</i><span class="menu-title" data-i18n="User Profile">Dashboard</span></a>
  <li class="bold"><a class="<?php echo e(Route::is('data-user.*') ? 'actived' : ''); ?> waves-effect waves-cyan" href="<?php echo e(route('data-user.index')); ?>"><i class="material-icons">people</i><span class="menu-title">Pengguna</span></a>
  
  <li class="navigation-header"><a class="navigation-header-text">Basis Pengetahuan</a><i class="navigation-header-icon material-icons">more_horiz</i>

  <li class="bold"><a class="<?php echo e(Route::is('tajwid.*') ? 'actived' : ''); ?> waves-effect waves-cyan" href="<?php echo e(route('tajwid.index')); ?>"><i class="material-icons">apps</i><span class="menu-title">Tajwid</span></a> 
  <li class="bold"><a class="<?php echo e(Route::is('tanda-tajwid.*') ? 'actived' : ''); ?> waves-effect waves-cyan" href="<?php echo e(route('tanda-tajwid.index')); ?>"><i class="material-icons dp48">new_releases</i><span class="menu-title">Huruf/ Tanda</span></a>
  <li class="bold"><a class="<?php echo e(Route::is('role-base.*') ? 'actived' : ''); ?> waves-effect waves-cyan" href="<?php echo e(route('role-base.index')); ?>"><i class="material-icons dp48">functions</i><span class="menu-title">Rule Tajwid</span></a>  
    <li class="bold"><a class="<?php echo e(Route::is('kategori.*') ? 'actived' : ''); ?> waves-effect waves-cyan" href="<?php echo e(route('kategori.index')); ?>"><i class="material-icons dp48">list</i><span class="menu-title">Kategori</span></a>  

  <li class="navigation-header"><a class="navigation-header-text">Kelola Konsultasi</a><i class="navigation-header-icon material-icons">more_horiz</i>
  <li class="bold"><a class="<?php echo e(Route::is('pertanyaan.*') ? 'actived' : ''); ?> waves-effect waves-cyan" href="<?php echo e(route('pertanyaan.index')); ?>"><i class="material-icons dp48">help</i><span class="menu-title">Pertanyaan</span></a> 

  <?php endif; ?>

  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role',['admin','guest'])): ?>
  <li class="navigation-header"><a class="navigation-header-text">Konsultasi</a><i class="navigation-header-icon material-icons">more_horiz</i>
  <li class="bold"><a class="<?php echo e(Route::is('konsultasi.*') ? 'actived' : ''); ?> waves-effect waves-cyan" href="<?php echo e(route('konsultasi')); ?>"><i class="material-icons dp48">chat</i><span class="menu-title">Konsultasi</span></a>  
  <?php endif; ?>
</ul>


<div class="navigation-background"></div><a class="sidenav-trigger btn-sidenav-toggle btn-floating btn-medium waves-effect waves-light hide-on-large-only white" href="#" data-target="slide-out"><i class="material-icons">menu</i></a><?php /**PATH /var/www/html/SP-Tajwid/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>