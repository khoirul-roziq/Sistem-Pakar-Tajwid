<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="author" content="Khoirul Roziq">
    <title><?php echo $__env->yieldContent('title'); ?> &mdash; Sistem Pakar Tajwid</title>
    <link rel="apple-touch-icon" href="<?php echo e(asset('images/favicon/apple-touch-icon-152x152.png')); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/logo/logo-kmnu(210x140).jpg')); ?>">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- BEGIN: VENDOR CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/materialize-adm/vendors/vendors.min.css')); ?>">
    <!-- END: VENDOR CSS-->

    <!-- BEGIN: Page Level CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/materialize-src/css/materialize.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/materialize-adm/css/themes/vertical-modern-menu-template/style.min.css')); ?>">
    <!-- END: Page Level CSS-->
    
    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/css/admin.css')); ?>">
    <!-- END: Custom CSS-->

    <?php echo $__env->yieldContent('styles'); ?>
    
  </head>

  <body class="vertical-layout vertical-menu-collapsible page-header-dark vertical-modern-menu preload-transitions 2-columns" data-open="click" data-menu="vertical-modern-menu" data-col="2-columns" onload = "autoClick();">
    <div id="app">
      <header class="page-topbar" id="header">
        <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </header>
    
      <aside class="sidenav-main nav-expanded nav-lock nav-collapsible sidenav-light sidenav-active-square">
        <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </aside>
    
      <div id="main">
        <?php echo $__env->yieldContent('content'); ?>
      </div>

      
    </div>

    <!-- BEGIN VENDOR JS-->
    <script src="<?php echo e(asset('assets/vendor/materialize-adm/js/vendors.min.js')); ?>"></script>
    <!-- BEGIN VENDOR JS-->

    <!-- BEGIN THEME  JS-->
    <script src="<?php echo e(asset('assets/vendor/materialize-adm/js/plugins.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/materialize-adm/js/scripts/customizer.min.js')); ?>"></script>
    <!-- END THEME  JS-->
    
    <!-- BEGIN PAGE LEVEL JS-->
    <?php echo $__env->yieldContent('scripts'); ?> 
    <!-- END PAGE LEVEL JS-->
    
  </body>
</html><?php /**PATH /var/www/html/SP-Tajwid/resources/views/layouts/admin.blade.php ENDPATH**/ ?>