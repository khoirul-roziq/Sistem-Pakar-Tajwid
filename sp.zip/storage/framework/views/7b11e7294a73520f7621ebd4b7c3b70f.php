<?php $__env->startSection('title', 'Login'); ?>


<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/css/auth.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <a href="https://www.freepik.com/free-photo/islamic-new-year-concept-with-copyspace_9259618.htm#query=al%20quran&position=6&from_view=search&track=ais"
        class="login-source-bg">Source background</a>

    <div class="row">
        <div class="container mt-4">
            <div class="col s12 m8 l5  offset-l1 offset-m2 z-depth-4 card-panel login">
                <div class="login-header">
                    <h5>Sistem Pakar Tajwid</h5>
                    <h6>Login</h6>
                </div>
                <?php if(session('message')): ?>
                    <div class="row">
                        <div class="col s10 m12 l12">
                            <div class="card-alert card cyan">
                                <div class="card-content white-text">
                                    <p>
                                        <i class="material-icons">check</i> <?php echo e(session('message')); ?>

                                    </p>
                                </div>
                                <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <form class="col s12" action="" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="input-field col s12 auth-mi">
                                <i class="material-icons prefix">email</i>
                                <input id="email" type="email"
                                    class="validate <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email">
                                <label for="email">Email</label>
                                <?php if($errors->has('email')): ?>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="helper-text"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php else: ?>
                                    <span class="helper-text" data-error="Email yang anda masukan salah!"
                                        data-success=""></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12 auth-mi">
                                <i class="material-icons prefix">key</i>
                                <input id="password" type="password"
                                    class="validate <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">
                                <label for="password">Kata Sandi</label>
                                <?php if($errors->has('password')): ?>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="helper-text"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php else: ?>
                                    <span class="helper-text" data-error="Kata Sandi yang anda masukan salah!"
                                        data-success=""></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12 auth-mc">
                                <p>
                                    <label>
                                        <input type="checkbox" checked="" name="remember" />
                                        <span>Ingat Saya</span>
                                    </label>
                                </p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="input-field col s12">
                                <button type="submit" class="waves-effect waves-light btn-large col s12"><i
                                        class="material-icons right">input</i>Masuk</button>
                            </div>
                            <div class="input-field col s12 auth-mc">
                                <a href="<?php echo e(route('registration')); ?>" class="waves-effect waves-light btn-small col s12"><i
                                        class="material-icons right">person_add</i>Registrasi</a>
                            </div>
                            <div class="input-field col s12">
                                <a href="<?php echo e(url('home')); ?>" class="waves-effect waves-light col s12"><i
                                        class="material-icons left">arrow_back</i>Halaman Beranda</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://pixinvent.com/materialize-material-design-admin-template/laravel/demo-1/js/scripts/ui-alerts.js">
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SP-Tajwid/resources/views/auth/login.blade.php ENDPATH**/ ?>