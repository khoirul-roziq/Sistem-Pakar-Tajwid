<?php $__env->startSection('scripts'); ?>
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="<?php echo e(asset('assets/vendor/materialize-src/js/plugins.min.js')); ?>"></script>
    <!-- END PAGE LEVEL JS-->

    <script>
        // Carousel
        $('.carousel.carousel-slider').carousel({
            fullWidth: true,
            indicators: true
        });

        // Sosmed button
        $(document).ready(function() {
            $('.fixed-action-btn').floatingActionButton({
                hoverEnabled: false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /var/www/html/SP-Tajwid/resources/views/partials/home/scripts.blade.php ENDPATH**/ ?>