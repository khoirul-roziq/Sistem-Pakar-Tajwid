<nav>
    <div class="nav-wrapper container">
        
        <ul class="right">

            <li><a href="<?php echo e(route('login')); ?>">Masuk</a></li>
            <li><a href="<?php echo e(route('registration')); ?>">Daftar</a></li>

            


        </ul>
    </div>
</nav>
<?php /**PATH /var/www/html/SP-Tajwid/resources/views/partials/home/navbar.blade.php ENDPATH**/ ?>