@extends('layouts.admin')

@section('title')
    Detail Data User
@endsection

@section('styles')

@endsection

@section('content')
    <!-- BEGIN: Page Main-->


    <!-- END: Page Main-->
@endsection

@section('scripts')

@endsection