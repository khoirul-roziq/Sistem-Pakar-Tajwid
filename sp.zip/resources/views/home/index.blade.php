{{-- Retrive home page --}}
@extends('layouts.home-page')

@section('styles')
    <link rel="stylesheet" href="{{ asset('assets/styles/css/home.css') }}">
@endsection