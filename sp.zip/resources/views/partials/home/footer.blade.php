<div class="footer" style="margin-left: -4%; height: 3rem;">
    <p>2023 Khoirul Roziq | Sistem Pakar Tajwid | Tugas Akhir</p>
</div>
