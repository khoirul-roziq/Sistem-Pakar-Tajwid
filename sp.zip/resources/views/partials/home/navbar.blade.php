<nav>
    <div class="nav-wrapper container">
        {{-- <a href="#!" class="brand-logo"><i class="material-icons">cloud</i></a> --}}
        <ul class="right">

            <li><a href="{{ route('login') }}">Masuk</a></li>
            <li><a href="{{ route('registration') }}">Daftar</a></li>

            {{-- <li><a href="{{ route('dashboard.index') }}">Dashboard</a></li> --}}


        </ul>
    </div>
</nav>
