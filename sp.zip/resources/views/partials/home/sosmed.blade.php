<div class="fixed-action-btn sosmed">
    <a class="btn-floating btn-large" href="https://khoirulroziq.com">
        <i class="large material-icons">link</i>
    </a>
</div>
