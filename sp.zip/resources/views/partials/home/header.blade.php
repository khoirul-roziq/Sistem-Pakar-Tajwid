@include('partials.home.navbar')
@include('partials.home.jumbotron')